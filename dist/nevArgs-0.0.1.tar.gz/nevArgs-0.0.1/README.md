# nevArgs

It's a simple package that using shlex formats your cli-like argument strings and format them into a dict
